import React, { useState, useEffect } from "react";

// ---------- Header component (receives props) ----------
function Header({ name, tagline, theme, onToggleTheme }) {
    return (
        <header className="header">
            <div>
                <h1>{name}</h1>
                <p>{tagline}</p>
            </div>

            <button className="theme-btn" onClick={onToggleTheme}>
                {theme === "light" ? "Switch to Dark" : "Switch to Light"}
            </button>
        </header>
    );
}

// ---------- Skills table (receives an array as a prop) ----------
function SkillsTable({ skills }) {
    return (
        <section className="card">
            <h2>Skills & Ratings</h2>

            <table>
                <thead>
                    <tr>
                        <th>Skill</th>
                        <th>Rating</th>
                    </tr>
                </thead>

                <tbody>
                    {skills.map((s) => (
                        <tr key={s.name}>
                            <td>{s.name}</td>
                            <td>
                                {"★".repeat(s.rating)}
                                {"☆".repeat(5 - s.rating)}
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </section>
    );
}

// ---------- Single project card ----------
function ProjectCard({ title, color }) {
    return (
        <div className="proj-card" style={{ backgroundColor: color }}>
            {title}
        </div>
    );
}

// ---------- Gallery, fetches project data with useEffect ----------
function Gallery() {
    const [projects, setProjects] = useState([]);
    const [loading, setLoading] = useState(true);

    // useEffect runs once after the first render
    useEffect(() => {
        // Simulating an API call using setTimeout
        const timer = setTimeout(() => {
            setProjects([
                { id: 1, title: "Library Management System", color: "#ffb703" },
                { id: 2, title: "Weather App", color: "#fb8500" },
                { id: 3, title: "Result Portal", color: "#8ecae6" },
                { id: 4, title: "Chat Application", color: "#219ebc" },
            ]);

            setLoading(false);
        }, 800);

        return () => clearTimeout(timer);
    }, []);

    if (loading) {
        return <p className="loading">Loading projects...</p>;
    }

    return (
        <section className="card">
            <h2>Project Gallery</h2>

            <div className="grid">
                {projects.map((p) => (
                    <ProjectCard
                        key={p.id}
                        title={p.title}
                        color={p.color}
                    />
                ))}
            </div>
        </section>
    );
}

// ---------- Root App component (owns theme state) ----------
function App() {
    const [theme, setTheme] = useState("light");

    const skills = [
        { name: "HTML & CSS", rating: 4 },
        { name: "JavaScript", rating: 3 },
        { name: "React JS", rating: 3 },
        { name: "Node & Express", rating: 2 },
    ];

    return (
        <div className={`app ${theme}`}>
            <Header
                name="My Portfolio"
                tagline="Welcome to my developer portfolio"
                theme={theme}
                onToggleTheme={() =>
                    setTheme(theme === "light" ? "dark" : "light")
                }
            />

            <SkillsTable skills={skills} />

            <Gallery />
        </div>
    );
}

export default App;
