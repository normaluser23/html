Experiment 10 - Express, MongoDB and Mongoose

Requirements:
- Node.js and npm
- MongoDB Atlas account and a database connection URI

Setup:
1. Open this folder in VS Code.
2. Open Terminal > New Terminal.
3. Run: npm install
4. Copy .env.example and rename the copy to .env.
5. Open .env and replace USERNAME, PASSWORD and CLUSTER with your MongoDB Atlas connection details.
6. Run: node server.js
7. Open: http://localhost:5002/api/projects

The server uses MongoDB Atlas. The API will not work until a valid MONGO_URI is entered in .env.

API routes:
- POST   /api/projects
- GET    /api/projects
- GET    /api/projects/:id
- PUT    /api/projects/:id
- DELETE /api/projects/:id
- POST   /api/contact
- GET    /api/messages

Do not share your .env file or publish your MongoDB password.
