Experiment 11 - Full Stack Integration

Requirements:
- Node.js and npm
- MongoDB Atlas account and connection URI

Run in VS Code:
1. Extract the ZIP and open the Experiment11 folder in VS Code.
2. Open Terminal > New Terminal.
3. Run: npm install
4. Run: Copy-Item .env.example .env
5. Open .env and replace USERNAME, PASSWORD and CLUSTER with your MongoDB Atlas connection details.
6. Run: npm run build
7. Run: npm start
8. Open http://localhost:5004

The React frontend is built into the public folder and served by Express.
The API and frontend use the same server, so frontend requests use /api/projects and /api/contact.

API routes:
- GET  /api/projects
- POST /api/projects
- POST /api/contact

The project and contact data are stored in MongoDB Atlas.
Do not share your .env file or publish your MongoDB password.
