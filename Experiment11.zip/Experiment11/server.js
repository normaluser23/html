require("dotenv").config();

const path = require("path");
const express = require("express");
const mongoose = require("mongoose");
const Project = require("./Project");
const Contact = require("./Contact");

const app = express();

app.use(express.json());

app.get("/api/projects", async (req, res) => {
    try {
        const projects = await Project.find().sort({ createdAt: -1 });
        res.json(projects);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.post("/api/projects", async (req, res) => {
    try {
        const project = await Project.create(req.body);
        res.status(201).json(project);
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
});

app.post("/api/contact", async (req, res) => {
    try {
        const entry = await Contact.create(req.body);
        res.status(201).json({
            message: "Message received, thank you!",
            entry
        });
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
});

app.use(express.static(path.join(__dirname, "public")));

app.get(/^(?!\/api).*/, (req, res) => {
    res.sendFile(path.join(__dirname, "public", "index.html"));
});

const PORT = process.env.PORT || 5004;

async function startServer() {
    try {
        await mongoose.connect(process.env.MONGO_URI);
        console.log("MongoDB Atlas connected");

        app.listen(PORT, () => {
            console.log(`MERN app running on http://localhost:${PORT}`);
        });
    } catch (err) {
        console.error("MongoDB connection error:", err.message);
        process.exit(1);
    }
}

startServer();
