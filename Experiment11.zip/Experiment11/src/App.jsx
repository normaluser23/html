import React, { useEffect, useState } from "react";

function Header() {
    return (
        <header className="header">
            <h1>Ananya Rao</h1>
            <p>Aspiring Full Stack Developer</p>
        </header>
    );
}

function ProjectCard({ title, stack, color }) {
    return (
        <div className="project-card" style={{ backgroundColor: color }}>
            <strong>{title}</strong>
            <p>{stack}</p>
        </div>
    );
}

const colors = ["#ffb703", "#fb8500", "#8ecae6", "#219ebc", "#023047"];

function Gallery() {
    const [projects, setProjects] = useState([]);
    const [loading, setLoading] = useState(true);
    const [newTitle, setNewTitle] = useState("");
    const [status, setStatus] = useState("");

    async function loadProjects() {
        setLoading(true);
        try {
            const res = await fetch("/api/projects");
            const data = await res.json();

            if (!res.ok) {
                throw new Error(data.error || "Unable to load projects.");
            }

            setProjects(data);
            setStatus("");
        } catch (err) {
            setStatus(err.message || "Unable to connect to the server.");
        } finally {
            setLoading(false);
        }
    }

    useEffect(() => {
        loadProjects();
    }, []);

    async function addProject(e) {
        e.preventDefault();

        if (!newTitle.trim()) return;

        try {
            const res = await fetch("/api/projects", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    title: newTitle.trim(),
                    stack: "MERN Stack"
                })
            });

            const data = await res.json();

            if (!res.ok) {
                throw new Error(data.error || "Unable to add project.");
            }

            setNewTitle("");
            await loadProjects();
        } catch (err) {
            setStatus(err.message || "Unable to add project.");
        }
    }

    return (
        <section className="card">
            <h2>Project Gallery</h2>

            <form className="add-form" onSubmit={addProject}>
                <input
                    type="text"
                    value={newTitle}
                    onChange={(e) => setNewTitle(e.target.value)}
                    placeholder="New project title"
                    aria-label="New project title"
                    required
                />
                <button type="submit">Add</button>
            </form>

            {status && <p className="status">{status}</p>}

            {loading ? (
                <p className="loading">Loading projects from server...</p>
            ) : (
                <div className="grid">
                    {projects.map((p, i) => (
                        <ProjectCard
                            key={p._id}
                            title={p.title}
                            stack={p.stack}
                            color={colors[i % colors.length]}
                        />
                    ))}
                </div>
            )}

            {!loading && projects.length === 0 && !status && (
                <p>No projects found.</p>
            )}
        </section>
    );
}

function ContactForm() {
    const [form, setForm] = useState({
        name: "",
        email: "",
        message: ""
    });
    const [status, setStatus] = useState("");

    function update(field) {
        return (e) => {
            setForm((current) => ({
                ...current,
                [field]: e.target.value
            }));
        };
    }

    async function submit(e) {
        e.preventDefault();
        setStatus("");

        try {
            const res = await fetch("/api/contact", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(form)
            });

            const data = await res.json();

            if (res.ok) {
                setStatus("Message saved to MongoDB, thank you!");
                setForm({ name: "", email: "", message: "" });
            } else {
                setStatus(data.error || "Something went wrong.");
            }
        } catch (err) {
            setStatus("Unable to connect to the server.");
        }
    }

    return (
        <section className="card">
            <h2>Contact Me</h2>

            <form className="contact-form" onSubmit={submit}>
                <input
                    type="text"
                    placeholder="Your name"
                    value={form.name}
                    onChange={update("name")}
                    required
                />

                <input
                    type="email"
                    placeholder="Your email"
                    value={form.email}
                    onChange={update("email")}
                    required
                />

                <textarea
                    placeholder="Your message (at least 10 characters)"
                    value={form.message}
                    onChange={update("message")}
                    minLength="10"
                    required
                />

                <button type="submit">Send</button>
            </form>

            {status && <p className="status">{status}</p>}
        </section>
    );
}

function App() {
    return (
        <div className="app">
            <Header />
            <Gallery />
            <ContactForm />
        </div>
    );
}

export default App;
