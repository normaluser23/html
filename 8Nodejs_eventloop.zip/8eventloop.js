
// Exp 08a - Understanding the Node.js event loop
// Order: Synchronous -> process.nextTick -> Promise -> Macrotasks

console.log("1. Start of script (synchronous)");

setTimeout(() => {
  console.log("5. setTimeout callback (macrotask, runs after 0ms delay)");
}, 0);

setImmediate(() => {
  console.log("6. setImmediate callback (runs in the check phase)");
});

Promise.resolve().then(() => {
  console.log("3. Promise.then callback (microtask)");
});

process.nextTick(() => {
  console.log("2. process.nextTick callback (runs before other microtasks)");
});

console.log("4. End of script (synchronous)");

// Expected order:
// 1 -> 4 -> 2 -> 3 -> 5/6 (or 6/5)
