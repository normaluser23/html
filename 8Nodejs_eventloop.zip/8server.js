
// Exp 08b - Basic HTTP server using only core Node.js modules
// Modules used: http, os, url

const http = require("http");
const os = require("os");
const { URL } = require("url");

// Portfolio data served as plain JSON
const projects = [
  { id: 1, title: "Library Management System" },
  { id: 2, title: "Weather App" },
  { id: 3, title: "Result Portal" },
];

const server = http.createServer((req, res) => {
  const parsedUrl = new URL(req.url, `http://${req.headers.host}`);

  console.log(`${req.method} ${parsedUrl.pathname}`);

  if (parsedUrl.pathname === "/") {
    res.writeHead(200, { "Content-Type": "text/plain" });
    res.end("Node core HTTP server is running. Try /projects or /system-info");

  } else if (parsedUrl.pathname === "/projects") {
    res.writeHead(200, { "Content-Type": "application/json" });
    res.end(JSON.stringify(projects, null, 2));

  } else if (parsedUrl.pathname === "/system-info") {
    // Demonstrating the os core module
    const info = {
      platform: os.platform(),
      cpuCores: os.cpus().length,
      totalMemoryMB: Math.round(os.totalmem() / 1024 / 1024),
      freeMemoryMB: Math.round(os.freemem() / 1024 / 1024),
      uptimeSeconds: Math.round(os.uptime()),
    };

    res.writeHead(200, { "Content-Type": "application/json" });
    res.end(JSON.stringify(info, null, 2));

  } else {
    res.writeHead(404, { "Content-Type": "text/plain" });
    res.end("404 - Route not found");
  }
});

const PORT = 5000;

server.listen(PORT, () => {
  console.log(`Server listening on http://localhost:${PORT}`);
});
