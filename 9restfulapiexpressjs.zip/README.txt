Experiment 09 - RESTful API with Express

Requirements:
- Node.js
- npm

Run in VS Code:
1. Open this folder in VS Code.
2. Open Terminal > New Terminal.
3. Run: npm install
4. Run: node server.js
5. Open http://localhost:5001/api/projects in your browser.

The API uses in-memory data. Projects and contact messages reset when the server restarts.

Available routes:
- GET    /api/projects
- GET    /api/projects/:id
- POST   /api/projects
- DELETE /api/projects/:id
- POST   /api/contact
- GET    /api/messages
